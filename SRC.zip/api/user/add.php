 <?php header('Content-Type: application/json'); ?>
{
    "success": true,
    "username": "FAKE",
    "message": "User \"FAKE\" is created. You can login with command: `:login [username] [password]`. Please don't check your email for verification.",
    "data": {
        "ResponseMetadata": {
            "RequestId": "a0128190-2c7b-4903-863c-ba42cb1d7f6c"
        },
        "MessageId": "010001925ff2fcc0-2dce2452-d0ad-4007-a375-add84148d2df-000000"
    }
}