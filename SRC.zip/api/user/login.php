<?php header('Content-Type: application/json'); ?>
{
    "success": true,
    "message": "Login successful.",
    "user": {
        "username": "FAKE",
        "role": "This is just a api!",
        "email": "NO",
        "settings": {
            "lang": "en-US",
            "theme": "terminal",
            "fullscreen": "off",
            "useSpeak": false,
            "useStats": false,
            "useEval": false,
            "useSystemRole": true,
            "functions": "Time,Weather,Redirection",
            "role": "",
            "store": "",
            "node": "",
            "memLength": 7,
            "passMask": true,
            "groupPassword": "i have no idea what this is"
        }
    }
}