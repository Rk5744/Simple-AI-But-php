<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

$api_key = 'Key here';


function sendEvent($data) {
    echo "data: $data\n\n"; 
    ob_flush();
    flush(); 
}


$user_input = $_GET['user_input'] ?? '';


function fetchGeminiResponse($user_input) {
    global $api_key;

    $curl = curl_init();

  
    $postData = json_encode([
        'contents' => [
            [
                'parts' => [
                    [
                        'text' => $user_input
                    ]
                ]
            ]
        ]
    ]);

    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=$api_key",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json"
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
    ]);


    $response = curl_exec($curl);
    curl_close($curl);


    $responseData = json_decode($response, true);


    if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
        $text = trim($responseData['candidates'][0]['content']['parts'][0]['text']);
        

        $segments = explode(' ', $text);
        foreach ($segments as $segment) {
            sendEvent($segment);
            sendEvent(' '); 
            usleep(50000); 
        }
    } else {
        sendEvent("###ERROR### No content found in the response.");
    }
}

sendEvent("###MODEL###Gemini-1.5-flash");  
sendEvent("###STATUS### Preparing...");
sleep(1);

sendEvent("###STATUS### Fetching AI response...");


fetchGeminiResponse($user_input);



sendEvent("###STATUS### Finished.");
echo "data: [DONE]\n\n";
  
ob_flush();
flush();
?>