<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #000;
            color: white;
            font-family: Arial, sans-serif;
        }
        .container {
            text-align: center;
        }
        .container h1 {
            font-size: 48px;
            margin: 0;
        }
        .container p {
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>404</h1>
        <p>This page could not be found.</p>
    </div>
</body>
</html>
