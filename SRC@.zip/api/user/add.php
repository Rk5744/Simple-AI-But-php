<?php header('Content-Type: application/json'); ?>
{
    "success": true,
    "username": "FAKE",
    "message": "Bro You cant add but :login FAKE hi20io20 will login",
    "data": {
        "ResponseMetadata": {
            "RequestId": "Nah"
        },
        "MessageId": "Nah"
    }
}