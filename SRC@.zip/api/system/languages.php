<?php header('Content-Type: application/json'); ?>
[
  {
    "language_code": "ar-EG",
    "name": "Arabic (Egypt)",
    "native_name": "العربية (مصر)"
  },
  {
    "language_code": "ar-IQ",
    "name": "Arabic (Iraq)",
    "native_name": "العربية (العراق)"
  },
  {
    "language_code": "ar-MA",
    "name": "Arabic (Morocco)",
    "native_name": "العربية (المغرب)"
  },
  {
    "language_code": "ar-SA",
    "name": "Arabic (Saudi Arabia)",
    "native_name": "العربية (السعودية)"
  },
  {
    "language_code": "ar-SY",
    "name": "Arabic (Syria)",
    "native_name": "العربية (سوريا)"
  },
  {
    "language_code": "bn-BD",
    "name": "Bengali",
    "native_name": "বাংলা"
  },
  {
    "language_code": "de-DE",
    "name": "German",
    "native_name": "Deutsch"
  },
  {
    "language_code": "en-US",
    "name": "English (US)",
    "native_name": "English (US)"
  },
  {
    "language_code": "en-GB",
    "name": "English (UK)",
    "native_name": "English (UK)"
  },
  {
    "language_code": "es-ES",
    "name": "Spanish",
    "native_name": "Español"
  },
  {
    "language_code": "fr-CA",
    "name": "French (Canada)",
    "native_name": "Français (Canada)"
  },
  {
    "language_code": "fr-FR",
    "name": "French (France)",
    "native_name": "Français (France)"
  },
  {
    "language_code": "hi-IN",
    "name": "Hindi (India)",
    "native_name": "हिन्दी"
  },
  {
    "language_code": "id-ID",
    "name": "Indonesian (Indonesia)",
    "native_name": "Bahasa Indonesia"
  },
  {
    "language_code": "it-IT",
    "name": "Italian (Italy)",
    "native_name": "Italiano"
  },
  {
    "language_code": "ja-JP",
    "name": "Japanese",
    "native_name": "日本語"
  },
  {
    "language_code": "ko-KR",
    "name": "Korean",
    "native_name": "한국어"
  },
  {
    "language_code": "nl-BE",
    "name": "Dutch (Belgium)",
    "native_name": "Nederlands (België)"
  },
  {
    "language_code": "nl-NL",
    "name": "Dutch (Netherlands)",
    "native_name": "Nederlands"
  },
  {
    "language_code": "pl-PL",
    "name": "Polish",
    "native_name": "Polski"
  },
  {
    "language_code": "pt-BR",
    "name": "Portuguese (Brazil)",
    "native_name": "Português (Brasil)"
  },
  {
    "language_code": "pt-PT",
    "name": "Portuguese (Portugal)",
    "native_name": "Português (Portugal)"
  },
  {
    "language_code": "ru-RU",
    "name": "Russian",
    "native_name": "Русский"
  },
  {
    "language_code": "sv-FI",
    "name": "Swedish (Finland)",
    "native_name": "Svenska (Finland)"
  },
  {
    "language_code": "sv-SE",
    "name": "Swedish (Sweden)",
    "native_name": "Svenska (Sverige)"
  },
  {
    "language_code": "tr-TR",
    "name": "Turkish (Turkey)",
    "native_name": "Türkçe"
  },
  {
    "language_code": "zh-CN",
    "name": "Chinese (S)",
    "native_name": "中文(简体)"
  },
  {
    "language_code": "zh-HK",
    "name": "Chinese (Hong Kong)",
    "native_name": "中文(香港)"
  },
  {
    "language_code": "zh-TW",
    "name": "Chinese (T)",
    "native_name": "中文(繁體)"
  }
]