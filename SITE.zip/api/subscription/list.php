<?php header('Content-Type: application/json'); ?>
{
  "user": {
    "name": "User",
    "price": "0",
    "usage_limit": {
      "daily_limit": "4320",
      "weekly_limit": "30240",
      "monthly_limit": "133920"
    }
  },
  "pro_user": {
    "name": "Pro User",
    "price": "0",
    "usage_limit": {
      "daily_limit": "4320",
      "weekly_limit": "30240",
      "monthly_limit": "133920"
    }
  },
  "super_user": {
    "name": "Super User",
    "price": "0",
    "usage_limit": {
      "daily_limit": "4320",
      "weekly_limit": "30240",
      "monthly_limit": "133920"
    }
  }
}