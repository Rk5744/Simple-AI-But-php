<?php header('Content-Type: application/json'); ?>
{
  "user": {
    "id": 1,
    "username": "FAKE",
    "group": "FAKE",
    "email": "FAKE@gmail.com",
    "email_verified": true,
    "email_subscription": "1",
    "settings": {
      "lang": "",
      "theme": "termnial",
      "fullscreen": "off",
      "useSpeak": false,
      "useStats": false,
      "useEval": false,
      "useSystemRole": true,
      "functions": "Time,Weather,Redirection",
      "role": "",
      "node": "",
      "memLength": 7,
      "passMask": true,
      "groupPassword": "Idk what the fuck this means",
      "stores": ""
    },
    "role": "super_user",
    "role_expires_at": null,
    "role_expires_at_h": "-",
    "balance": 0.3,
    "user_role_count": 0,
    "store_count": 1,
    "node_count": 2,
    "created_at_h": "10/06/2024"
  }
}