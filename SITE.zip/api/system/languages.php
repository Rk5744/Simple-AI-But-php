<?php 
header('Content-Type: application/json'); 
?>
[
  {
    "language_code": "en-US",
    "name": "English (US)",
    "native_name": "English (US)"
  }
]
