<?php header('Content-Type: application/json'); ?>
{
  "result": {
    "role_content_system": "***",
    "welcome_message": "",
    "querying": "Querying...",
    "generating": "Generating...",
    "searching": "Searching...",
    "waiting": "",
    "init_placeholder": ":help",
    "enter": "",
    "temperature": 0.8,
    "top_p": 1,
    "max_tokens": 4096,
    "use_function_calling": true,
    "use_node_ai": true,
    "use_payment": true,
    "use_email": true,
    "minimalist": false
  }
}